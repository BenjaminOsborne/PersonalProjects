﻿namespace pdfforge.PDFCreator.Core.Settings.Enums
{
    public enum SelectPrinter
    {
        DefaultPrinter,
        ShowDialog,
        SelectedPrinter
    }
}