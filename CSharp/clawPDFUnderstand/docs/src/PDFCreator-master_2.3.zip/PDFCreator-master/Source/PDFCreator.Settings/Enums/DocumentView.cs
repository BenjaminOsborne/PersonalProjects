﻿namespace pdfforge.PDFCreator.Core.Settings.Enums
{
    public enum DocumentView
    {
        NoOutLineNoThumbnailImages
        ,Outline
        ,ThumbnailImages
        ,FullScreen
        ,ContentGroupPanel
        ,AttachmentsPanel
    }
}
