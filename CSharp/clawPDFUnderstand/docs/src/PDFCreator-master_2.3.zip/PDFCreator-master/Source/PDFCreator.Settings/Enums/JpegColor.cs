﻿namespace pdfforge.PDFCreator.Core.Settings.Enums
{
    public enum JpegColor
    {
        Color24Bit
        ,Gray8Bit 
    }
}
