﻿namespace pdfforge.PDFCreator.Core.Settings.Enums
{
    public enum UpdateInterval
    {
        Never
        ,Daily
        ,Weekly
        ,Monthly
    }
}