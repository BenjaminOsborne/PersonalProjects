﻿namespace pdfforge.PDFCreator.Core.Settings.Enums
{
    public enum ColorModel
    {
        Rgb
        ,Cmyk
        ,Gray
    }
}
