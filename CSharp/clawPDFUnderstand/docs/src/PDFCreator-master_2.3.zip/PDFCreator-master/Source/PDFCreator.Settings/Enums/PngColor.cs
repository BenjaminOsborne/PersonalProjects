﻿namespace pdfforge.PDFCreator.Core.Settings.Enums
{
    public enum PngColor
    {
        Color32BitTransp
        ,Color24Bit
        ,Color8Bit
        ,Color4Bit	
        ,Gray8Bit
	    ,BlackWhite//2Bit
    }
}
