﻿namespace pdfforge.PDFCreator.Core.Settings.Enums
{
    public enum CompressionMonochrome
    {
        CcittFaxEncoding
        ,Zip
        ,RunLengthEncoding
    }
}
