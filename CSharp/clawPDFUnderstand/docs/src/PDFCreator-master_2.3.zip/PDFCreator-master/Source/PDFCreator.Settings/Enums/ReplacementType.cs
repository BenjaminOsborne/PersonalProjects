﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace pdfforge.PDFCreator.Core.Settings.Enums
{
    public enum ReplacementType
    {
        Replace,
        Start,
        End,
        RegEx
    }
}
