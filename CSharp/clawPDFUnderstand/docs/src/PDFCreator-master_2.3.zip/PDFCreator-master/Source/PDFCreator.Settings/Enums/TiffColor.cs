﻿namespace pdfforge.PDFCreator.Core.Settings.Enums
{
    public enum TiffColor
    {
        Color24Bit 
        ,Color12Bit
        ,Gray8Bit
        ,BlackWhiteG3Fax 
        ,BlackWhiteG4Fax
        ,BlackWhiteLzw		
    }
}
