﻿using pdfforge.DataStorage;
using pdfforge.DataStorage.Storage;

namespace PDFCreator.Core.UnitTest.Mocks
{
    class MockStorage : IStorage
    {
        public void SetData(Data data)
        {
            
        }

        public void ReadData()
        {
            
        }

        public void ReadData(string path)
        {
            
        }

        public void WriteData()
        {
            
        }

        public void WriteData(string path)
        {
            
        }
    }
}