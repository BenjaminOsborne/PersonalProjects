﻿namespace pdfforge.PDFCreator.Core.Jobs
{
    public interface ITempFolderProvider
    {
        string TempFolder { get; }
    }
}
