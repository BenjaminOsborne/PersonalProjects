﻿namespace pdfforge.PDFCreator.Core.Printer
{
    public enum PortType
    {
        PostScript,
        Xps
    }
}