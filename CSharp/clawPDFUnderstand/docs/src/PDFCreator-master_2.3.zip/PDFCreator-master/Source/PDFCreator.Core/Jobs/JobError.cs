﻿namespace pdfforge.PDFCreator.Core.Jobs
{
    public enum JobError
    {
        None,
        Unknown,
        Ghostscript
    }
}
