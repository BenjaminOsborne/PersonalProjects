﻿namespace pdfforge.PDFCreator.Core.Jobs
{
    public class JobTranslations
    {
        public string EmailSignature { get; set; }
    }
}
