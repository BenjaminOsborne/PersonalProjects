﻿namespace pdfforge.PDFCreator.Core.Jobs
{
    public enum JobType
    {
        PsJob,
        XpsJob
    }
}
