﻿using System;

namespace pdfforge.PDFCreator.Helper
{
    internal class UpdateEventArgs : EventArgs
    {
        public bool SkipVersion;
    }
}