﻿using System.Windows.Controls;

namespace pdfforge.PDFCreator.Views.UserControls
{
    internal partial class ApiServicesTab : UserControl
    {
        public ApiServicesTab()
        {
            InitializeComponent();
        }
    }
}