﻿namespace pdfforge.PDFCreator.Startup
{
    internal interface IAppStart
    {
        bool Run();
    }
}
