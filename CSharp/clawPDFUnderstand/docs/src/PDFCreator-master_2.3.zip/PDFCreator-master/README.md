# PDFCreator
PDFCreator - The free PDF Converter

This is the public GitHub repository of PDFCreator. Right now, this is a snapshot of our private [GitLab](https://about.gitlab.com/) repository and requires some manual work to get this to compile on your machine. Over the time, we will try to split up things to have our internal stuff separated from the public parts, to be able to give you access to our [FAKE build scripts](http://fsharp.github.io/FAKE/) and our [Paket repository](https://fsprojects.github.io/Paket/). This will allow you to easily create build and to contribute to the development of PDFCreator more easily.
